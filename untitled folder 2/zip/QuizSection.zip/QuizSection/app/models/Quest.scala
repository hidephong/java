package models

/**
 * Created by tuanna on 5/21/14.
 */
case class Quiz(name:String,quest:String)
object Quiz{

}