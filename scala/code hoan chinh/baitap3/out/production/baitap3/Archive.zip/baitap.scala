/**
 * Created by tuanna on 5/19/14.
 */
import scala.io.Source
import java.io._
import scala.collection.mutable

object baitap {
  val words  = mutable.Set.empty[String]
  def main(args: Array[String]) {
    readFileByScala(args(0))
    writeToFile(args(1))
  }


def readFileByScala(filename:String) {
  val fileName = filename
  val bufferSource = Source.fromFile(fileName)
  for (line <- bufferSource.getLines) {
    val wordsArray = line.split("[!,.()‘\"\'\\]\\[ \\s+]+")
    for (word <- wordsArray)  {
      words += word.toLowerCase
      println(word)
    }
  }
  bufferSource.close
}

def writeToFile(filename:String) {
  val fileName = filename
  val pw = new BufferedWriter(new FileWriter(fileName))

  for (word <- words)  {
    if(word.length>=3)
  pw.write(word+"\n")
  }
  pw.close()
}
  def timeMethod(method: () => Unit) {
    val start = System.nanoTime
    method()
    val end = System.nanoTime
    println("Method took " + (end - start)/1000000000.0 + " seconds.")
  }

}